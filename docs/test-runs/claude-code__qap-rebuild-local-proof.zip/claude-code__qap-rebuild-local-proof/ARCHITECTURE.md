# Architecture

## System Role

This repository is the **L9 Website Factory** — it designs, builds, and deploys Astro lead-generation websites from a canonical domain specification. `Quantum-L9/SEO-Bot` works alongside it to grow each deployed site's SEO and Domain Authority. The factory is client-agnostic; a worked reference client lives under `examples/supplemental-insurance-pros/`.

Numbered Architecture Decision Records live in `docs/adr/`. That directory is the only canonical ADR location.

## Layers

1. Domain specification: source of truth for business, audience, service area, compliance, and conversion assumptions.
2. Website object model: generated intermediate contract.
3. Astro implementation: client-neutral `astro_template/` materialized into
   `build/sites/<client>/` (ADR-0007). Root `src/` is the factory, not the site.
4. LLM intelligence layer: `@quantum-l9/llm-router` installed from GitHub Packages, consumed via `src/services/llm.ts`.
   Stages declare capabilities; the router selects models (ADR-0003). Redesign
   page copy is SEO-Bot-owned (ADR-0002).
5. Verification layer: scripts in `scripts/` and evidence in
   `build/evidence/<client>/<build>/` (ADR-0016). Launch-env reports stay in
   `validation/`.
6. Deployment layer: per-client GitHub repo + Vercel project; local `astro build`
   is a gate, not the deploy artifact (ADR-0007).

## LLM Provider Integration

`src/services/llm.ts` is the single LLM adapter for AI-powered operations:
- Content generation (page copy, blog posts, meta descriptions)
- Design intelligence (color selection, layout reasoning)
- Visual QA (screenshot-based layout validation)
- Redesign-improve strategic operations (extraction, pattern synthesis, blueprint)

Search-grounded research and fact verification are not provided by the adapter: they fail
closed rather than producing model-only claims (ADR-0020).

Every text, reasoning and vision call goes directly to DeepSeek through `src/services/llm.ts` (ADR-0020): no router, no fallback provider, no automatic retry or model escalation. A per-build allowance is reserved before every dispatch. See `contracts/llm_router_integration.yaml` (v2.0.0) for the full mapping.

## Runtime Boundaries

The static site must not contain private CRM credentials, Vercel tokens, analytics secrets, or email delivery credentials. Any sensitive integration must be handled through environment variables and server-side or provider-managed endpoints.

## Integration Boundaries

- Forms: use `PUBLIC_FORM_ENDPOINT` only for an intentionally public-safe form endpoint.
- CRM: the configured CRM provider (`CRM_PROVIDER`, e.g. `acculynx`, `hubspot`, `salesforce`, `none`) is phase 2 verification; API keys must not be exposed to browser code.
- Analytics: configured by public provider/id values only.
- Vercel: deployment through environment variables and CLI wrapper.

## Non-Goals

- No custom backend is included unless added later.
- No production deployment is claimed without Vercel URL evidence.
- No legal/compliance claim is finalized until approved text and license details are supplied.

## Secrets hydration

Website-Bot hydrates secrets from **Infisical** at process start via
`@quantum-l9/infisical-config` (`await loadSecrets()` in `scripts/run-pipeline.ts`).
Bootstrap env: `INFISICAL_CLIENT_ID`, `INFISICAL_CLIENT_SECRET`, `INFISICAL_PROJECT_ID`.
Secret names in Infisical match application env var names (e.g. `PUBLIC_POSTHOG_KEY`).
GitHub Actions injects Infisical bootstrap (`INFISICAL_*`) plus not-yet-migrated
deploy secrets; Node `loadSecrets()` performs vault hydration. CLI `infisical run`
wrap is deferred (no curl|bash installer in CI).
See `docs/adr/ADR-0009-infisical-secrets-plane.md`.

## Architecture decisions

Numbered ADRs live in [`docs/adr/`](docs/adr/README.md). Design notes that are
not numbered decisions live in [`docs/architecture/`](docs/architecture/README.md).
Historical source docs that those ADRs were extracted from live in
[`docs/archive/`](docs/archive/README.md).
