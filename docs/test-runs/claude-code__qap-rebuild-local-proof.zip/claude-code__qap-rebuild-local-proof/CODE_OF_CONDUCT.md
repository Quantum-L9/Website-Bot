# Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in the Quantum-L9 community
a harassment-free experience for everyone, regardless of age, body size, visible or invisible disability,
ethnicity, sex characteristics, gender identity and expression, level of experience, education,
socioeconomic status, nationality, personal appearance, race, caste, color, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

## Our Standards

Examples of behavior that contributes to a positive environment:
- Demonstrating empathy and kindness toward other people
- Being respectful of differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive feedback
- Accepting responsibility and apologizing to those affected by our mistakes
- Focusing on what is best not just for us as individuals, but for the overall community

Examples of unacceptable behavior:
- The use of sexualized language or imagery, and sexual attention or advances of any kind
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information without their explicit permission
- Other conduct which could reasonably be considered inappropriate in a professional setting

## Enforcement Responsibilities

The Quantum-L9 platform team (`@Quantum-L9/platform`) is responsible for clarifying and enforcing this Code of Conduct.
They will take appropriate and fair corrective action in response to any behavior deemed inappropriate, threatening, offensive, or harmful.

## Scope

This Code of Conduct applies within all community spaces and also applies when an individual is officially
representing the community in public spaces.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the platform team
via GitHub Security Advisories (for confidential reports) or by contacting `@Quantum-L9/platform` directly.

All complaints will be reviewed and investigated promptly and fairly.

## Enforcement Guidelines

**1. Correction** — Private written warning, clarity on violation, request for public apology.  
**2. Warning** — Warning with consequences for continued behavior; no interaction with involved parties for a specified period.  
**3. Temporary Ban** — Temporary ban from community interaction.  
**4. Permanent Ban** — Permanent ban for sustained, severe, or repeated violations.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant v2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).
