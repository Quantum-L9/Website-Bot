# Deployment

## Target

Deployment target is Vercel. Deployment must be preview-first. Production deployment requires explicit operator authorization.

## Prerequisites

1. Node.js 18+ installed.
2. npm 9+ installed.
3. Dependencies installed: `npm ci`.

## Required Environment Variables

See `.env.example` for the canonical variable list. See `config/launch-env.required.yaml`
for the fail-closed launch contract (Vercel: `VERCEL_TOKEN` + `VERCEL_TEAM_ID` globally;
per-client `CLIENT_VERCEL_PROJECT_ID` / deploy hook — not legacy `VERCEL_ORG_ID` /
`VERCEL_PROJECT_ID`).

### LLM Intelligence (required for generation and visual QA)

| Variable | Purpose |
|----------|---------|
| `DEEPSEEK_API_KEY` | DeepSeek API key — direct text, reasoning and vision calls (ADR-0020) |
| `CLIENT_ID` | Unique client identifier for usage attribution |
| `LLM_BUILD_BUDGET_USD` | Per-build LLM allowance in USD, reserved before every dispatch (default: 10) |
| `LLM_MAX_REQUESTS_PER_BUILD` | Maximum DeepSeek requests per build (default: 200) |
| `SITE_URL` | Live site URL for visual QA and SEO verification |

### Vercel Deployment (required for deploy)

Single per-client identity model. The deploy runtime
(`src/stages/VercelDeployStage.ts`, `SiteAssemblerStage.ts`) reads only the global
`VERCEL_TOKEN` + `VERCEL_TEAM_ID`; project identity is per-client. The legacy shared
`VERCEL_ORG_ID`/`VERCEL_PROJECT_ID` are not consumed and have been retired.

| Variable | Scope | Purpose |
|----------|-------|---------|
| `VERCEL_TOKEN` | global (secret) | Vercel deployment token |
| `VERCEL_TEAM_ID` | global (identifier) | team-scoped deploys |
| `CLIENT_VERCEL_PROJECT_ID` | per-client | project identity (or embed `deploy.vercel_project_id` in the DomainSpec) |
| `CLIENT_VERCEL_DEPLOY_HOOK` | per-client (secret) | deploy-hook trigger (optional; API mode uses token + project id) |

### Site Runtime (required for launch)

Names match the fail-closed launch contract in `config/launch-env.required.yaml`
(validated by `scripts/verify-launch-env.mjs`). Values marked **secret** are
server-side only and must never be exposed to browser code.

| Variable | Purpose |
|----------|---------|
| `FORM_PROVIDER` | Lead-form provider (e.g. webhook, formspree, custom, crm_proxy) |
| `FORM_ENDPOINT_URL` | Server-side/trusted endpoint that receives lead submissions |
| `FORM_WEBHOOK_SECRET` | **secret** — form webhook validation |
| `LEAD_NOTIFICATION_EMAIL` | Lead notification recipient (if email routing is used) |
| `ANALYTICS_PROVIDER` | Approved analytics provider |
| `ANALYTICS_MEASUREMENT_ID` | Provider measurement/site id |
| `CRM_PROVIDER` | CRM provider selector (e.g. `acculynx`, `hubspot`, `salesforce`, `none`) |
| `CRM_API_TOKEN` | **secret** — CRM API token for the configured provider (phase 2) |
| `CRM_CLIENT_SECRET` | **secret** — CRM client secret for the configured provider (phase 2) |

## Deployment Preconditions

Before any preview deployment:

```bash
npm ci
npm run pipeline:local-proof -- --spec=<domain-spec>
npm run verify:all
```

If external checks are blocked because credentials are missing, the report must state the exact missing values.

## Preview Deployment Flow

A preview deploy is the Vercel stage of a full end-to-end run (`VERCEL_TARGET=preview`, the default):

```bash
npm ci
npm run verify:all
VERCEL_TARGET=preview npm run pipeline:end-to-end -- --spec=<domain-spec>
```

After Vercel returns a preview URL:

```bash
VERIFY_BASE_URL=https://preview-url.example npm run verify:all
```

Save deployment logs and verification evidence before production promotion.

## Visual QA (Optional Pre-Production)

After preview deployment, run visual QA to validate layout across viewports:

```bash
SITE_URL=https://preview-url.example npm run verify:visual-qa
```

This captures screenshots at desktop, tablet, and mobile viewports and validates layout via LLM vision. Results are written to `validation/visual_qa_report.json`.

## Production Deployment Flow

Only after preview verification passes and the operator explicitly authorizes production:

```bash
npm run verify:launch-env
WEBSITE_BOT_ALLOW_PRODUCTION=true VERCEL_TARGET=production npm run pipeline:end-to-end -- --spec=<domain-spec>
```

After production deploy:

```bash
VERIFY_BASE_URL=https://production-domain.example npm run verify:all
```

## Fail-Closed Launch Environment Gate

Production deployment must not proceed until:

```bash
npm run verify:launch-env
```

The command hydrates via `scripts/lib/hydrate-secrets.mjs` when Infisical bootstrap
(`INFISICAL_*`) is present (same contract as `scripts/run-pipeline.ts`), then applies the
existing fail-closed launch/legal checks. It writes `validation/launch_env_report.json`
(including `source_mode` / `bootstrap_present` only — never secret values) and exits
nonzero while required vars are missing or approval gates remain unresolved. Secrets must
be set in Vercel, Infisical, or a secure local secret store. Do not commit `.env.local`.

## Triggered-Deploy Credential Preflight

`verify:launch-env` covers the launch/legal contract. The build+deploy pipeline additionally
reads execution credentials at runtime; a triggered deploy must have these present or it fails.
The deploy workflows (`build-site.yml`, `deploy-to-vercel.yml`) run this preflight before the
pipeline so a missing credential fails fast with a readable message:

```bash
npm run verify:deploy-secrets       # production: FAIL_CLOSED on missing required creds
npm run verify:deploy-secrets --ci  # CI: warnings only, exit 0
```

It hydrates through the same shared helper when Infisical bootstrap is present, then applies
existing presence checks. It writes `validation/deploy_secrets_report.json` (with the same
minimal `source_mode` / `bootstrap_present` fields). Infisical connectivity alone is not a PASS.

### Required in GitHub for a triggered deploy

Repo (or org, scoped to this repo) → **Settings → Secrets and variables → Actions**.

**Secrets**

| Secret | Consumed by | Purpose |
|---|---|---|
| `DEEPSEEK_API_KEY` | `src/services/llm.ts` | content/design/schema/vision generation via direct DeepSeek (required; ADR-0020) |
| `VERCEL_TOKEN` | `VercelDeployStage` | Vercel deploy + correlation (required) |
| `GITHUB_SITE_TOKEN` | `ClientSourcePublishStage` (`env://GITHUB_SITE_TOKEN`) | push generated source to the client repo (required) |
| `CLIENT_VERCEL_DEPLOY_HOOK` | `SiteAssemblerStage` | deploy-hook trigger (or use API mode via project id) |
| `POSTHOG_KEY` / `PUBLIC_POSTHOG_KEY` | `PostHogSnippetStage` | analytics snippet (optional; `PUBLIC_POSTHOG_KEY` preferred) |
| `DATAFORSEO_LOGIN` / `DATAFORSEO_PASSWORD` | SEO baseline | keyword data (optional) |
| `SEO_BOT_URL` / `SEO_BOT_API_KEY` | SEO handoff | `--auto-register-seo-bot` (optional) |

**Variables** (identifiers, not secrets)

| Variable | Purpose |
|---|---|
| `VERCEL_TEAM_ID` | team-scoped Vercel deploys (required) |
| `CLIENT_VERCEL_PROJECT_ID` | per-client project identity (or embed `deploy.vercel_project_id` in the DomainSpec) |

`GITHUB_REPO_ID` is supplied automatically by the workflow (`github.event.repository.id`).

> Org secrets are only visible to a triggered run when the org secret's **Repository access**
> policy includes this repository. Confirm under Org → Settings → Secrets and variables → Actions.

## Rollback

Rollback depends on Vercel deployment history. At minimum, record:

- previous deployment URL or Vercel deployment ID
- rollback method used
- operator approval if production
- post-rollback smoke-test result

## Do Not

- Do not deploy production before preview passes.
- Do not commit `.env.local`.
- Do not hardcode API keys or Vercel tokens.
- Do not call deployment successful without URL and verification evidence.
- Do not treat local build success as deployment proof.
- LLM calls go directly to DeepSeek (`src/services/llm.ts`, ADR-0020); there is no router build or runtime step.
